using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Index index = new Index();
        public Form1()
        {
            InitializeComponent();
            index.AddIndexItem("������", new int[] { 1, 3, 7 });
            index.AddIndexItem("�����", new int[] { 2, 4, 8 });
            index.AddIndexItem("����", new int[] { 3, 5, 9 });
            index.DisplayIndex(listBox1);
        }

        private void button1_Click(object sender, EventArgs e)
        {           
            string[] mass = textBox3.Text.Split(' ');
            int[] x = new int[mass.Length];
            for (int i = 0; i < mass.Length; i++)
            {
                x[i] = int.Parse(mass[i]);
            }
            index.AddIndexItem(textBox2.Text, x);
            listBox1.Items.Clear();
            index.DisplayIndex(listBox1);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(index.DisplayPageNumbers(textBox4.Text));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            index.RemoveIndexItem(textBox5.Text);
            listBox1.Items.Clear();
            index.DisplayIndex(listBox1);
        }
    }
}

