﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    class IndexItem
    {
        public string Word { get; set; }
        public ArrayList PageNumbers { get; set; }

        public IndexItem(string word)
        {
            Word = word;
            PageNumbers = new ArrayList();
        }
    }

    class Index
    {
        public ArrayList IndexItems { get; set; }

        public Index()
        {
            IndexItems = new ArrayList();
        }

        public void AddIndexItem(string word, int[] pageNumbers)
        {
            IndexItem newItem = new IndexItem(word);
            foreach (int pageNum in pageNumbers)
            {
                newItem.PageNumbers.Add(pageNum);
            }
            IndexItems.Add(newItem);
        }

        public void DisplayIndex(ListBox listBox1)
        {
            foreach (IndexItem item in IndexItems)
            {
                string str = (item.Word + ": ");
                foreach (int num in item.PageNumbers)
                {
                    str += (num + " ");
                }
                listBox1.Items.Add(str);
            }            
        }

        public string DisplayPageNumbers(string word)
        {
            string str = "";
            foreach (IndexItem item in IndexItems)
            {
                if (item.Word == word)
                {
                    str += (word + ": ");
                    foreach (int num in item.PageNumbers)
                    {
                        str += (num + " ");
                    }
                    return str;
                }
            }
            return "Слово не найдено";
        }

        public void RemoveIndexItem(string word)
        {
            foreach (IndexItem item in IndexItems)
            {
                if (item.Word == word)
                {
                    IndexItems.Remove(item);
                    return;
                }
            }
        }
    }
}
